// Offline deterministic integration-style tests: Express route and middleware handlers.
// Does not represent a live HTTP penetration test or real Watchmode load benchmark.
const fs=require('fs'),vm=require('vm'),path=require('path'),crypto=require('crypto');
const src=fs.readFileSync(path.join(__dirname,'../server/server.js'),'utf8');
const pause=ms=>new Promise(r=>setTimeout(r,ms));
function setup({delay=0,quota=Infinity,providerStatus=200,empty=false,pages=1,key='TEST_KEY'}={}){
 const routes={},mw=[];let upstream=0;const writes=[];globalThis.__testQuota={};
 const app={disable(){},use(...a){mw.push(a)},get(p,...f){routes['GET '+p]=f},post(p,...f){routes['POST '+p]=f},listen(){}};
 const express=()=>app;express.json=()=>function json(req,res,next){next()};express.static=(root,opts)=>({staticRoot:root,options:opts});
 const fakeFs={...fs,readFileSync(p,...args){if(String(p).endsWith('/accounts.json'))throw Error('no db');if(String(p).endsWith('/quotas.json'))return JSON.stringify(globalThis.__testQuota||{});return fs.readFileSync(p,...args)},mkdirSync(p){if(String(p).endsWith('quotas.lock'))return;},rmdirSync(){},writeFileSync(p,data){writes.push([p,data]);if(String(p).includes('quotas.json.'))globalThis.__nextQuota=JSON.parse(data)},renameSync(p){if(String(p).includes('quotas.json.'))globalThis.__testQuota=globalThis.__nextQuota}};
 const fetch=async u=>{upstream++;await pause(delay);if(upstream>quota||providerStatus!==200)return {ok:false,status:upstream>quota?429:providerStatus};const url=new URL(u),p=url.pathname;let body;
 if(p==='/v1/sources/')body=[{id:1,name:'Netflix',type:'sub',regions:['US']}];
 else if(p==='/v1/genres/')body=[{id:10,name:'Drama'}];
 else if(p==='/v1/search/')body={title_results:[{id:101,name:'Film',type:'movie',year:2025}]};
 else if(p==='/v1/list-titles/'){const page=Number(url.searchParams.get('page'));body={titles:!empty&&page<=pages?Array.from({length:50},(_,i)=>({id:101+i+50*(page-1),title:'Film'})):[]}}
 else if(p.endsWith('/details/'))body={title:'Film',type:'movie',genre_names:['Drama'],user_rating:7};
 else if(p.endsWith('/sources/'))body=empty?[]:[{source_id:1,region:'US',type:'sub',web_url:'https://example.test/film'}];
 else body={};return {ok:true,json:async()=>body}};
 const ctx={require:x=>x==='express'?express:x==='dotenv'?{config:()=>{}}:x==='fs'?fakeFs:require(x),__dirname:path.join(__dirname,'../server'),process:{env:{WATCHMODE_API_KEY:key,PORT:'0',WATCHMODE_REQUESTS_PER_MINUTE:'100000',ACCOUNT_REQUESTS_PER_MINUTE:'100000'},pid:1234},console:{log(){}},fetch,URL,AbortSignal,Map,Set,Date,Number,String,Array,Object,Promise,Error,Buffer,setTimeout,SharedArrayBuffer,Atomics,module:{exports:{}},};
 vm.runInNewContext(src,ctx,{filename:'server.js'});
 async function call(route,query={},opts={}){return new Promise(resolve=>{const [method,url]=route.split(' ');const headers={host:'localhost:3000',...opts.headers};const req={method,path:url,url:url,originalUrl:opts.originalUrl||url,ip:opts.ip||'127.0.0.1',headers,query,body:opts.body||{},socket:{remoteAddress:'127.0.0.1'}};
 const res={statusCode:200,headers:{},status(n){this.statusCode=n;return this},setHeader(k,v){this.headers[k.toLowerCase()]=v;return this},json(body){resolve({status:this.statusCode,body,headers:this.headers})},sendStatus(n){resolve({status:n,body:null,headers:this.headers})}};
 const handlers=[];for(const m of mw){const [prefix,...funcs]=m;if(typeof prefix==='string'){if(url.startsWith(prefix))handlers.push(...funcs.filter(x=>typeof x==='function'))}else if(typeof prefix==='function')handlers.push(prefix)}handlers.push(...(routes[route]||[]));
 let i=0;function next(){if(i>=handlers.length){resolve({status:404});return}const fn=handlers[i++];try{Promise.resolve(fn(req,res,next)).catch(e=>resolve({status:500,error:String(e)}))}catch(e){resolve({status:500,error:String(e)})}}next();})}
 return {call,get upstream(){return upstream},mw,writes};
}

const cases=[];
const base={firstName:'Alex',lastName:'Sample',email:'alex@example.com',username:'alex_dev',password:'A unique long passphrase! 2031'};
const variations=[
 ['valid',{},201],['username short',{username:'abc'},400],['username starts digit',{username:'1alex'},400],['username symbols',{username:'alex-name'},400],['username spaces',{username:'alex name'},400],['username double underscore',{username:'alex__dev'},400],['username too long',{username:'a'.repeat(25)},400],['password too short',{password:'Short123!'},400],['common password',{password:'password123456'},400],['repeated password',{password:'aaaaaaaaaaaa'},400],['contains username',{password:'alex_dev is my password!'},400],['contains email local part',{password:'alex secret long passphrase'},400],['password control character',{password:'long password\nwith newline'},400],['max password length',{password:'Unique passphrase 2026 '+ 'x'.repeat(105)},201],['too long password',{password:'x'.repeat(129)},400]
];
(async()=>{
 for(const [name,patch,expected] of variations){const a=setup();const r=await a.call('POST /api/auth/register',{}, {body:{...base,...patch}});cases.push({name,expected,actual:r.status,pass:r.status===expected});}
 // Duplicate username, email, case-insensitivity and login.
 const a=setup();const r1=await a.call('POST /api/auth/register',{}, {body:base});const r2=await a.call('POST /api/auth/register',{}, {body:{...base,email:'new@example.com',username:'ALEX_DEV'}});
 cases.push({name:'duplicate username case-insensitive',expected:409,actual:r2.status,pass:r1.status===201&&r2.status===409});
 const r3=await a.call('POST /api/auth/register',{}, {body:{...base,username:'other_user',email:'ALEX@EXAMPLE.COM'}});
 cases.push({name:'duplicate email case-insensitive',expected:409,actual:r3.status,pass:r3.status===409});
 const r4=await a.call('POST /api/auth/login',{}, {body:{identity:'ALEX_DEV',password:base.password}});
 cases.push({name:'login with valid account',expected:200,actual:r4.status,pass:r4.status===200});
 fs.writeFileSync(path.join(__dirname,'account_policy_results.json'),JSON.stringify({summary:{total:cases.length,passed:cases.filter(c=>c.pass).length,failed:cases.filter(c=>!c.pass).length},cases},null,2));
 console.log(JSON.stringify({total:cases.length,passed:cases.filter(c=>c.pass).length,failed:cases.filter(c=>!c.pass).length}));
 for(const c of cases.filter(x=>!x.pass))console.log(c);
 if(cases.some(c=>!c.pass))process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1});
