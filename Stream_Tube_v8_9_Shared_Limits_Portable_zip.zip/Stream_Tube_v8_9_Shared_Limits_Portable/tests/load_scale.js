// Offline deterministic integration-style tests: Express route and middleware handlers.
// Does not represent a live HTTP penetration test or real Watchmode load benchmark.
const fs=require('fs'),vm=require('vm'),path=require('path'),crypto=require('crypto');
const src=fs.readFileSync(path.join(__dirname,'../server/server.js'),'utf8');
const pause=ms=>new Promise(r=>setTimeout(r,ms));
function setup({delay=0,quota=Infinity,providerStatus=200,empty=false,pages=1,key='TEST_KEY'}={}){
 const routes={},mw=[];let upstream=0;const writes=[];globalThis.__testQuota={};
 const app={disable(){},use(...a){mw.push(a)},get(p,...f){routes['GET '+p]=f},post(p,...f){routes['POST '+p]=f},listen(){}};
 const express=()=>app;express.json=()=>function json(req,res,next){next()};express.static=(root,opts)=>({staticRoot:root,options:opts});
 const fakeFs={...fs,readFileSync(p,...args){if(String(p).endsWith('/accounts.json'))throw Error('no db');if(String(p).endsWith('/quotas.json'))return JSON.stringify(globalThis.__testQuota||{});return fs.readFileSync(p,...args)},mkdirSync(p){if(String(p).endsWith('quotas.lock'))return;},rmdirSync(){},writeFileSync(p,data){writes.push([p,data]);if(String(p).includes('quotas.json.'))globalThis.__nextQuota=JSON.parse(data)},renameSync(p){if(String(p).includes('quotas.json.'))globalThis.__testQuota=globalThis.__nextQuota}};
 const fetch=async u=>{upstream++;await pause(delay);if(upstream>quota||providerStatus!==200)return {ok:false,status:upstream>quota?429:providerStatus};const url=new URL(u),p=url.pathname;let body;
 if(p==='/v1/sources/')body=[{id:1,name:'Netflix',type:'sub',regions:['US']}];
 else if(p==='/v1/genres/')body=[{id:10,name:'Drama'}];
 else if(p==='/v1/search/')body={title_results:[{id:101,name:'Film',type:'movie',year:2025}]};
 else if(p==='/v1/list-titles/'){const page=Number(url.searchParams.get('page'));body={titles:!empty&&page<=pages?Array.from({length:50},(_,i)=>({id:101+i+50*(page-1),title:'Film'})):[]}}
 else if(p.endsWith('/details/'))body={title:'Film',type:'movie',genre_names:['Drama'],user_rating:7};
 else if(p.endsWith('/sources/'))body=empty?[]:[{source_id:1,region:'US',type:'sub',web_url:'https://example.test/film'}];
 else body={};return {ok:true,json:async()=>body}};
 const ctx={require:x=>x==='express'?express:x==='dotenv'?{config:()=>{}}:x==='fs'?fakeFs:require(x),__dirname:path.join(__dirname,'../server'),process:{env:{WATCHMODE_API_KEY:key,PORT:'0',WATCHMODE_REQUESTS_PER_MINUTE:'100000',ACCOUNT_REQUESTS_PER_MINUTE:'100000'},pid:1234},console:{log(){}},fetch,URL,AbortSignal,Map,Set,Date,Number,String,Array,Object,Promise,Error,Buffer,setTimeout,SharedArrayBuffer,Atomics,module:{exports:{}},};
 vm.runInNewContext(src,ctx,{filename:'server.js'});
 async function call(route,query={},opts={}){return new Promise(resolve=>{const [method,url]=route.split(' ');const headers={host:'localhost:3000',...opts.headers};const req={method,path:url,url:url,originalUrl:opts.originalUrl||url,ip:opts.ip||'127.0.0.1',headers,query,body:opts.body||{},socket:{remoteAddress:'127.0.0.1'}};
 const res={statusCode:200,headers:{},status(n){this.statusCode=n;return this},setHeader(k,v){this.headers[k.toLowerCase()]=v;return this},json(body){resolve({status:this.statusCode,body,headers:this.headers})},sendStatus(n){resolve({status:n,body:null,headers:this.headers})}};
 const handlers=[];for(const m of mw){const [prefix,...funcs]=m;if(typeof prefix==='string'){if(url.startsWith(prefix))handlers.push(...funcs.filter(x=>typeof x==='function'))}else if(typeof prefix==='function')handlers.push(prefix)}handlers.push(...(routes[route]||[]));
 let i=0;function next(){if(i>=handlers.length){resolve({status:404});return}const fn=handlers[i++];try{Promise.resolve(fn(req,res,next)).catch(e=>resolve({status:500,error:String(e)}))}catch(e){resolve({status:500,error:String(e)})}}next();})}
 return {call,get upstream(){return upstream},mw,writes};
}

const {performance}=require('perf_hooks');
async function authenticated(a){const r=await a.call('POST /api/auth/register',{}, {body:{firstName:'Test',lastName:'User',email:'test@example.com',username:'tester',password:'AnOriginalLongPassphrase!93'}});return r.headers['set-cookie']?.split(';')[0]} 
const records=[];
async function load(n,kind){
 const a=setup();const cookie=await authenticated(a);
 const opts={headers:{cookie}};
 const q={services:'netflix',genres:'Drama',count:'8'};
 const start=performance.now();let accepted=0,limited=0,other=0;
 // A bounded local handler simulation, NOT real sockets or independent users.
 for(let offset=0;offset<n;offset+=250){
   const batch=await Promise.all(Array.from({length:Math.min(250,n-offset)},()=>a.call('GET /api/recommendations',q,opts)));
   for(const r of batch){if(r.status===200)accepted++;else if(r.status===429)limited++;else other++;}
 }
 records.push({scenario:kind,logicalRequests:n,accepted,rateLimited:limited,other,upstreamCalls:a.upstream,elapsedMs:Math.round(performance.now()-start),notes:'Mocked same-IP requests, bounded batches of 250; no HTTP sockets or real concurrent users.'});
 console.log(kind,JSON.stringify(records.at(-1)));
}
(async()=>{
 for(const n of [1000,10000,100000])await load(n,'MOCK-'+n);
 // 1M extrapolation is intentionally NOT presented as an executed test.
 records.push({scenario:'MODEL-1000000',logicalRequests:1000000,accepted:120,rateLimited:999880,other:0,notes:'Calculated fixed-window per-IP outcome assuming all requests arrive inside one minute, with no reset, and no concurrent state changes. Not executed.'});
 fs.writeFileSync(path.join(__dirname,'load_results.json'),JSON.stringify({environment:'Node VM Express-handler harness; Watchmode mocked; single IP; no live server or 1M sockets',records},null,2));
})().catch(e=>{console.error(e);process.exitCode=1});
