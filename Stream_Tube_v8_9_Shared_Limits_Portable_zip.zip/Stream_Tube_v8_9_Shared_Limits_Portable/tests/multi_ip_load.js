// Offline deterministic integration-style tests: Express route and middleware handlers.
// Does not represent a live HTTP penetration test or real Watchmode load benchmark.
const fs=require('fs'),vm=require('vm'),path=require('path'),crypto=require('crypto');
const src=fs.readFileSync(path.join(__dirname,'../server/server.js'),'utf8');
const pause=ms=>new Promise(r=>setTimeout(r,ms));
function setup({delay=0,quota=Infinity,providerStatus=200,empty=false,pages=1,key='TEST_KEY'}={}){
 const routes={},mw=[];let upstream=0;const writes=[];globalThis.__testQuota={};
 const app={disable(){},use(...a){mw.push(a)},get(p,...f){routes['GET '+p]=f},post(p,...f){routes['POST '+p]=f},listen(){}};
 const express=()=>app;express.json=()=>function json(req,res,next){next()};express.static=(root,opts)=>({staticRoot:root,options:opts});
 const fakeFs={...fs,readFileSync(p,...args){if(String(p).endsWith('/accounts.json'))throw Error('no db');if(String(p).endsWith('/quotas.json'))return JSON.stringify(globalThis.__testQuota||{});return fs.readFileSync(p,...args)},mkdirSync(p){if(String(p).endsWith('quotas.lock'))return;},rmdirSync(){},writeFileSync(p,data){writes.push([p,data]);if(String(p).includes('quotas.json.'))globalThis.__nextQuota=JSON.parse(data)},renameSync(p){if(String(p).includes('quotas.json.'))globalThis.__testQuota=globalThis.__nextQuota}};
 const fetch=async u=>{upstream++;await pause(delay);if(upstream>quota||providerStatus!==200)return {ok:false,status:upstream>quota?429:providerStatus};const url=new URL(u),p=url.pathname;let body;
 if(p==='/v1/sources/')body=[{id:1,name:'Netflix',type:'sub',regions:['US']}];
 else if(p==='/v1/genres/')body=[{id:10,name:'Drama'}];
 else if(p==='/v1/search/')body={title_results:[{id:101,name:'Film',type:'movie',year:2025}]};
 else if(p==='/v1/list-titles/'){const page=Number(url.searchParams.get('page'));body={titles:!empty&&page<=pages?Array.from({length:50},(_,i)=>({id:101+i+50*(page-1),title:'Film'})):[]}}
 else if(p.endsWith('/details/'))body={title:'Film',type:'movie',genre_names:['Drama'],user_rating:7};
 else if(p.endsWith('/sources/'))body=empty?[]:[{source_id:1,region:'US',type:'sub',web_url:'https://example.test/film'}];
 else body={};return {ok:true,json:async()=>body}};
 const ctx={require:x=>x==='express'?express:x==='dotenv'?{config:()=>{}}:x==='fs'?fakeFs:require(x),__dirname:path.join(__dirname,'../server'),process:{env:{WATCHMODE_API_KEY:key,PORT:'0',WATCHMODE_REQUESTS_PER_MINUTE:'100000',ACCOUNT_REQUESTS_PER_MINUTE:'100000'},pid:1234},console:{log(){}},fetch,URL,AbortSignal,Map,Set,Date,Number,String,Array,Object,Promise,Error,Buffer,setTimeout,SharedArrayBuffer,Atomics,module:{exports:{}},};
 vm.runInNewContext(src,ctx,{filename:'server.js'});
 async function call(route,query={},opts={}){return new Promise(resolve=>{const [method,url]=route.split(' ');const headers={host:'localhost:3000',...opts.headers};const req={method,path:url,url:url,originalUrl:opts.originalUrl||url,ip:opts.ip||'127.0.0.1',headers,query,body:opts.body||{},socket:{remoteAddress:'127.0.0.1'}};
 const res={statusCode:200,headers:{},status(n){this.statusCode=n;return this},setHeader(k,v){this.headers[k.toLowerCase()]=v;return this},json(body){resolve({status:this.statusCode,body,headers:this.headers})},sendStatus(n){resolve({status:n,body:null,headers:this.headers})}};
 const handlers=[];for(const m of mw){const [prefix,...funcs]=m;if(typeof prefix==='string'){if(url.startsWith(prefix))handlers.push(...funcs.filter(x=>typeof x==='function'))}else if(typeof prefix==='function')handlers.push(prefix)}handlers.push(...(routes[route]||[]));
 let i=0;function next(){if(i>=handlers.length){resolve({status:404});return}const fn=handlers[i++];try{Promise.resolve(fn(req,res,next)).catch(e=>resolve({status:500,error:String(e)}))}catch(e){resolve({status:500,error:String(e)})}}next();})}
 return {call,get upstream(){return upstream},mw,writes};
}


const {performance}=require('perf_hooks');
const records=[];
async function auth(a){const r=await a.call('POST /api/auth/register',{}, {body:{firstName:'Test',lastName:'User',email:'multi@example.com',username:'multiuser',password:'AUniqueLongPassphrase!93'}});if(r.status!==200&&r.status!==201)throw Error('Registration failed '+JSON.stringify(r));return r.headers['set-cookie'].split(';')[0]}
async function run(label,ips,perIp,{spoof=false}={}){
 const a=setup();const cookie=await auth(a);const q={services:'netflix',genres:'Drama',count:'8'};
 let accepted=0,limited=0,other=0;const start=performance.now();
 // Bounded batches, NOT actual HTTP sockets or simultaneous users.
 const total=ips*perIp;
 for(let offset=0;offset<total;offset+=250){
  const batch=await Promise.all(Array.from({length:Math.min(250,total-offset)},(_,j)=>{
   const ipIndex=Math.floor((offset+j)/perIp);
   const ip=spoof?'198.51.100.77':`10.${(ipIndex>>16)&255}.${(ipIndex>>8)&255}.${ipIndex&255}`;
   const headers={cookie};if(spoof)headers['x-forwarded-for']=`192.0.${Math.floor(ipIndex/256)}.${ipIndex%256}`;
   return a.call('GET /api/recommendations',q,{ip,headers});
  }));
  for(const r of batch){if(r.status===200)accepted++;else if(r.status===429)limited++;else other++}
 }
 const result={scenario:label,distinctSimulatedIPs:ips,requestsPerIP:perIp,totalRequests:total,accepted,rateLimited:limited,other,upstreamCalls:a.upstream,elapsedMs:Math.round(performance.now()-start)};
 records.push(result);console.log(JSON.stringify(result));
}
(async()=>{
 await run('100 IPs x 10',100,10);
 await run('1000 IPs x 10',1000,10);
 await run('10000 IPs x 1',10000,1);
 await run('10 IPs x 200',10,200);
 await run('1 shared IP x 200',1,200);
 await run('Spoofed forwarded header x 200',200,1,{spoof:true});
 require('fs').writeFileSync(require('path').join(__dirname,'multi_ip_results.json'),JSON.stringify({method:'Node VM handler simulation, simulated IP values; not real TCP clients',records},null,2));
})().catch(e=>{console.error(e);process.exitCode=1});
