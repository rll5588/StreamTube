// Offline deterministic integration-style tests: Express route and middleware handlers.
// Does not represent a live HTTP penetration test or real Watchmode load benchmark.
const fs=require('fs'),vm=require('vm'),path=require('path'),crypto=require('crypto');
const src=fs.readFileSync(path.join(__dirname,'../server/server.js'),'utf8');
const pause=ms=>new Promise(r=>setTimeout(r,ms));
function setup({delay=0,quota=Infinity,providerStatus=200,empty=false,pages=1,key='TEST_KEY'}={}){
 const routes={},mw=[];let upstream=0;const writes=[];globalThis.__testQuota={};
 const app={disable(){},use(...a){mw.push(a)},get(p,...f){routes['GET '+p]=f},post(p,...f){routes['POST '+p]=f},listen(){}};
 const express=()=>app;express.json=()=>function json(req,res,next){next()};express.static=(root,opts)=>({staticRoot:root,options:opts});
 const fakeFs={...fs,readFileSync(p,...args){if(String(p).endsWith('/accounts.json'))throw Error('no db');if(String(p).endsWith('/quotas.json'))return JSON.stringify(globalThis.__testQuota||{});return fs.readFileSync(p,...args)},mkdirSync(p){if(String(p).endsWith('quotas.lock'))return;},rmdirSync(){},writeFileSync(p,data){writes.push([p,data]);if(String(p).includes('quotas.json.'))globalThis.__nextQuota=JSON.parse(data)},renameSync(p){if(String(p).includes('quotas.json.'))globalThis.__testQuota=globalThis.__nextQuota}};
 const fetch=async u=>{upstream++;await pause(delay);if(upstream>quota||providerStatus!==200)return {ok:false,status:upstream>quota?429:providerStatus};const url=new URL(u),p=url.pathname;let body;
 if(p==='/v1/sources/')body=[{id:1,name:'Netflix',type:'sub',regions:['US']}];
 else if(p==='/v1/genres/')body=[{id:10,name:'Drama'}];
 else if(p==='/v1/search/')body={title_results:[{id:101,name:'Film',type:'movie',year:2025}]};
 else if(p==='/v1/list-titles/'){const page=Number(url.searchParams.get('page'));body={titles:!empty&&page<=pages?Array.from({length:50},(_,i)=>({id:101+i+50*(page-1),title:'Film'})):[]}}
 else if(p.endsWith('/details/'))body={title:'Film',type:'movie',genre_names:['Drama'],user_rating:7};
 else if(p.endsWith('/sources/'))body=empty?[]:[{source_id:1,region:'US',type:'sub',web_url:'https://example.test/film'}];
 else body={};return {ok:true,json:async()=>body}};
 const ctx={require:x=>x==='express'?express:x==='dotenv'?{config:()=>{}}:x==='fs'?fakeFs:require(x),__dirname:path.join(__dirname,'../server'),process:{env:{WATCHMODE_API_KEY:key,PORT:'0',WATCHMODE_REQUESTS_PER_MINUTE:'100000',ACCOUNT_REQUESTS_PER_MINUTE:'100000'},pid:1234},console:{log(){}},fetch,URL,AbortSignal,Map,Set,Date,Number,String,Array,Object,Promise,Error,Buffer,setTimeout,SharedArrayBuffer,Atomics,module:{exports:{}},};
 vm.runInNewContext(src,ctx,{filename:'server.js'});
 async function call(route,query={},opts={}){return new Promise(resolve=>{const [method,url]=route.split(' ');const headers={host:'localhost:3000',...opts.headers};const req={method,path:url,url:url,originalUrl:opts.originalUrl||url,ip:opts.ip||'127.0.0.1',headers,query,body:opts.body||{},socket:{remoteAddress:'127.0.0.1'}};
 const res={statusCode:200,headers:{},status(n){this.statusCode=n;return this},setHeader(k,v){this.headers[k.toLowerCase()]=v;return this},json(body){resolve({status:this.statusCode,body,headers:this.headers})},sendStatus(n){resolve({status:n,body:null,headers:this.headers})}};
 const handlers=[];for(const m of mw){const [prefix,...funcs]=m;if(typeof prefix==='string'){if(url.startsWith(prefix))handlers.push(...funcs.filter(x=>typeof x==='function'))}else if(typeof prefix==='function')handlers.push(prefix)}handlers.push(...(routes[route]||[]));
 let i=0;function next(){if(i>=handlers.length){resolve({status:404});return}const fn=handlers[i++];try{Promise.resolve(fn(req,res,next)).catch(e=>resolve({status:500,error:String(e)}))}catch(e){resolve({status:500,error:String(e)})}}next();})}
 return {call,get upstream(){return upstream},mw,writes};
}
const q={services:'netflix',genres:'Drama',count:'8'};
const tests=[];async function test(id,name,fn){try{const r=await fn();tests.push({id,name,pass:!!r.pass,details:r.details||''})}catch(e){tests.push({id,name,pass:false,details:String(e)})}}
async function authenticated(a){const r=await a.call('POST /api/auth/register',{}, {body:{firstName:'Test',lastName:'User',email:'test@example.com',username:'tester',password:'AnOriginalLongPassphrase!93'}});return r.headers['set-cookie']?.split(';')[0]}
(async()=>{
 await test('LOAD-01','baseline recommendations',async()=>{const a=setup();const c=await authenticated(a);const r=await a.call('GET /api/recommendations',q,{headers:{cookie:c}});return {pass:r.status===200&&r.body.results.length===8,details:`status ${r.status}, results ${r.body?.results?.length}`}});
 for(const [id,n] of [['LOAD-02',10],['LOAD-03',30],['LOAD-04',100]])await test(id,`${n} simultaneous identical requests`,async()=>{const a=setup({delay:3});const c=await authenticated(a);const r=await Promise.all(Array.from({length:n},()=>a.call('GET /api/recommendations',q,{headers:{cookie:c}})));return {pass:r.every(x=>x.status===200)&&a.upstream<=20,details:`upstream ${a.upstream}, statuses ${[...new Set(r.map(x=>x.status))]}`}});
 await test('LOAD-05','429 quota error',async()=>{const a=setup({quota:2});const c=await authenticated(a);const r=await a.call('GET /api/recommendations',q,{headers:{cookie:c}});return {pass:r.status===502&&!JSON.stringify(r.body).includes('TEST_KEY'),details:`status ${r.status}, calls ${a.upstream}`}});
 await test('LOAD-06','503 provider outage',async()=>{const a=setup({providerStatus:503});const c=await authenticated(a);const r=await a.call('GET /api/recommendations',q,{headers:{cookie:c}});return {pass:r.status===502&&a.upstream===3,details:`status ${r.status}, retries ${a.upstream}`}});
 await test('LOAD-07','slow provider concurrent calls',async()=>{const a=setup({delay:8});const c=await authenticated(a);const r=await Promise.all(Array.from({length:10},()=>a.call('GET /api/recommendations',q,{headers:{cookie:c}})));return {pass:r.every(x=>x.status===200)&&a.upstream<=20,details:`upstream ${a.upstream}`}});
 await test('LOAD-08','empty catalog',async()=>{const a=setup({empty:true});const c=await authenticated(a);const r=await a.call('GET /api/recommendations',q,{headers:{cookie:c}});return {pass:r.status===200&&r.body.results.length===0}});
 for(const [id,services] of [['LOAD-09',''],['LOAD-10','invalid']])await test(id,'invalid/empty subscription',async()=>{const a=setup();const c=await authenticated(a);const r=await a.call('GET /api/recommendations',{...q,services},{headers:{cookie:c}});return {pass:r.status===200&&r.body.results.length===0}});
 await test('LOAD-11','exclude watched first eight',async()=>{const a=setup();const c=await authenticated(a);const r=await a.call('GET /api/recommendations',{...q,watched:Array.from({length:8},(_,i)=>101+i).join(',')},{headers:{cookie:c}});return {pass:r.body.results.length===8&&!r.body.results.some(x=>x.id<=108)}});
 await test('LOAD-12','paginate beyond watched first page',async()=>{const a=setup({pages:2});const c=await authenticated(a);const r=await a.call('GET /api/recommendations',{...q,watched:Array.from({length:50},(_,i)=>101+i).join(',')},{headers:{cookie:c}});return {pass:r.body.results.length===8&&r.body.pagination.pagesSearched===2}});
 await test('LOAD-13','unknown genre rejected before catalog scan',async()=>{const a=setup();const c=await authenticated(a);const r=await a.call('GET /api/recommendations',{...q,genres:'NotARealGenre'},{headers:{cookie:c}});return {pass:r.status===200&&r.body.results.length===0&&r.body.pagination.pagesSearched===0}});
 await test('LOAD-14','invalid search',async()=>{const a=setup();const r=await a.call('GET /api/search',{q:'a'});return {pass:r.status===400&&a.upstream===0}});
 await test('LOAD-15','concurrent searches deduplicated',async()=>{const a=setup({delay:4});const r=await Promise.all(Array.from({length:12},()=>a.call('GET /api/search',{q:'Matrix'})));return {pass:r.every(x=>x.status===200)&&a.upstream===3,details:`calls ${a.upstream}`}});
 await test('LOAD-16','missing API key',async()=>{const a=setup({key:''});const r=await a.call('GET /api/search',{q:'Matrix'});return {pass:r.status===502}});
 await test('LOAD-17','service directory',async()=>{const a=setup();const r=await a.call('GET /api/services');return {pass:r.status===200&&r.body.services.length===6}});
 await test('SEC-01','short search rejected',async()=>{const a=setup();return {pass:(await a.call('GET /api/search',{q:'x'})).status===400}});
 await test('SEC-02','long search rejected',async()=>{const a=setup();return {pass:(await a.call('GET /api/search',{q:'a'.repeat(101)})).status===400}});
 await test('SEC-03','HTML-like search safe JSON',async()=>{const a=setup();const r=await a.call('GET /api/search',{q:'<script>alert(1)</script>'});return {pass:r.status===200&&!JSON.stringify(r.body).includes('TEST_KEY'),details:'Browser DOM XSS not tested'}});
 await test('SEC-04','recommendations require session',async()=>{const a=setup();return {pass:(await a.call('GET /api/recommendations',q)).status===401}});
 await test('SEC-05','rate limit 40+ auth attempts',async()=>{const a=setup();const r=await Promise.all(Array.from({length:40},()=>a.call('POST /api/auth/login',{}, {body:{identity:'x',password:'bad'}})));return {pass:r.some(x=>x.status===429),details:`429: ${r.filter(x=>x.status===429).length}`}});
 await test('SEC-06','25 concurrent cache misses deduped',async()=>{const a=setup({delay:5});await Promise.all(Array.from({length:25},()=>a.call('GET /api/services')));return {pass:a.upstream===1,details:`calls ${a.upstream}`}});
 await test('SEC-07','oversized watched input rejected',async()=>{const a=setup();const c=await authenticated(a);const r=await a.call('GET /api/recommendations',{...q,watched:'1,'.repeat(20000)},{headers:{cookie:c}});return {pass:r.status===400||r.status===414,details:`status ${r.status}`}});
 await test('SEC-08','invalid genre no fallback',async()=>{const a=setup();const c=await authenticated(a);const r=await a.call('GET /api/recommendations',{...q,genres:'FakeGenre'},{headers:{cookie:c}});return {pass:r.body.results.length===0&&r.body.pagination.pagesSearched===0}});
 await test('SEC-09','health excludes API key',async()=>{const a=setup();const r=await a.call('GET /api/health');return {pass:r.status===200&&!JSON.stringify(r.body).includes('TEST_KEY')}});
 await test('SEC-10','dotfiles denied',async()=>{const a=setup();return {pass:a.mw.some(x=>x[0]?.options?.dotfiles==='deny')}});
 await test('SEC-11','security headers present',async()=>{const a=setup();const r=await a.call('GET /api/health');return {pass:!!r.headers['content-security-policy']&&r.headers['x-content-type-options']==='nosniff'}});
 await test('SEC-12','provider URL HTTPS validation',async()=>{const a=setup();const r=await a.call('GET /api/search',{q:'Film'});return {pass:r.body.results[0].providers[0].url.startsWith('https://')}});
 await test('SEC-13','no client API key or plaintext password storage',async()=>{const root=path.join(__dirname,'..');const content=['index.html','js/app.js','js/netflix-api.js','js/recommendations.js'].map(x=>fs.readFileSync(path.join(root,x),'utf8')).join('\n');return {pass:!content.includes('WATCHMODE_API_KEY')&&!content.includes('account.password')&&!content.includes('keyAccount')}});
 await test('SEC-14','recommendation count capped at 12',async()=>{const a=setup();const c=await authenticated(a);const r=await a.call('GET /api/recommendations',{...q,count:'100000'},{headers:{cookie:c}});return {pass:r.body.requested===12}});
 await test('SEC-15','malformed query rejected',async()=>{const a=setup();const r=await a.call('GET /api/recommendations',{services:{nested:'netflix'},genres:{nested:'Drama'}});return {pass:r.status===400}});
 // New tests for changes not covered by the original 32
 await test('NEW-01','register and login with hashed passwords',async()=>{const a=setup();const c=await authenticated(a);const r=await a.call('GET /api/auth/me',{}, {headers:{cookie:c}});return {pass:r.status===200&&a.writes.some(([p,d])=>d.includes('"hash"')&&!d.includes('AnOriginalLongPassphrase!93'))}});
 await test('NEW-02','unauthenticated auth/me blocked',async()=>{const a=setup();return {pass:(await a.call('GET /api/auth/me')).status===401}});
 await test('NEW-03','logout invalidates session',async()=>{const a=setup();const c=await authenticated(a);await a.call('POST /api/auth/logout',{}, {headers:{cookie:c}});return {pass:(await a.call('GET /api/auth/me',{}, {headers:{cookie:c}})).status===401}});
 await test('NEW-04','cross-origin authentication rejected',async()=>{const a=setup();const r=await a.call('POST /api/auth/login',{}, {headers:{origin:'https://evil.test'},body:{identity:'a',password:'b'}});return {pass:r.status===403}});
 await test('NEW-05','server private files not exposed via static route',async()=>{const a=setup();return {pass:(await a.call('GET /server/private/accounts.json')).status===404}});
 await test('NEW-06','missing session not reported as signed in',async()=>{const a=setup();return {pass:(await a.call('GET /api/auth/me',{}, {headers:{cookie:'st_session=bad'}})).status===401}});
 const summary={total:tests.length,passed:tests.filter(x=>x.pass).length,failed:tests.filter(x=>!x.pass).length};
 fs.writeFileSync(path.join(__dirname,'results.json'),JSON.stringify({method:'Offline mocked Watchmode, route+middleware harness; not a live Express/HTTP/browser security test',summary,tests},null,2));
 console.log(JSON.stringify(summary));for(const t of tests.filter(x=>!x.pass))console.log('FAIL',t.id,t.name,t.details);
 process.exitCode=summary.failed?1:0;
})().catch(e=>{console.error(e);process.exitCode=1});
