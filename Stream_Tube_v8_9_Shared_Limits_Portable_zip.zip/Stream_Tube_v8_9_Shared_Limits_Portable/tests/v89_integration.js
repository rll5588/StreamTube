// Offline deterministic integration-style tests: Express route and middleware handlers.
// Does not represent a live HTTP penetration test or real Watchmode load benchmark.
const fs=require('fs'),vm=require('vm'),path=require('path'),crypto=require('crypto');
const src=fs.readFileSync(path.join(__dirname,'../server/server.js'),'utf8');
const pause=ms=>new Promise(r=>setTimeout(r,ms));
function setup({delay=0,quota=Infinity,providerStatus=200,empty=false,pages=1,key='TEST_KEY'}={}){
 const routes={},mw=[];let upstream=0;const writes=[];globalThis.__testQuota={};
 const app={disable(){},use(...a){mw.push(a)},get(p,...f){routes['GET '+p]=f},post(p,...f){routes['POST '+p]=f},listen(){}};
 const express=()=>app;express.json=()=>function json(req,res,next){next()};express.static=(root,opts)=>({staticRoot:root,options:opts});
 const fakeFs={...fs,readFileSync(p,...args){if(String(p).endsWith('/accounts.json'))throw Error('no db');if(String(p).endsWith('/quotas.json'))return JSON.stringify(globalThis.__testQuota||{});return fs.readFileSync(p,...args)},mkdirSync(p){if(String(p).endsWith('quotas.lock'))return;},rmdirSync(){},writeFileSync(p,data){writes.push([p,data]);if(String(p).includes('quotas.json.'))globalThis.__nextQuota=JSON.parse(data)},renameSync(p){if(String(p).includes('quotas.json.'))globalThis.__testQuota=globalThis.__nextQuota}};
 const fetch=async u=>{upstream++;await pause(delay);if(upstream>quota||providerStatus!==200)return {ok:false,status:upstream>quota?429:providerStatus};const url=new URL(u),p=url.pathname;let body;
 if(p==='/v1/sources/')body=[{id:1,name:'Netflix',type:'sub',regions:['US']}];
 else if(p==='/v1/genres/')body=[{id:10,name:'Drama'}];
 else if(p==='/v1/search/')body={title_results:[{id:101,name:'Film',type:'movie',year:2025}]};
 else if(p==='/v1/list-titles/'){const page=Number(url.searchParams.get('page'));body={titles:!empty&&page<=pages?Array.from({length:50},(_,i)=>({id:101+i+50*(page-1),title:'Film'})):[]}}
 else if(p.endsWith('/details/'))body={title:'Film',type:'movie',genre_names:['Drama'],user_rating:7};
 else if(p.endsWith('/sources/'))body=empty?[]:[{source_id:1,region:'US',type:'sub',web_url:'https://example.test/film'}];
 else body={};return {ok:true,json:async()=>body}};
 const ctx={require:x=>x==='express'?express:x==='dotenv'?{config:()=>{}}:x==='fs'?fakeFs:require(x),__dirname:path.join(__dirname,'../server'),process:{env:{WATCHMODE_API_KEY:key,PORT:'0',WATCHMODE_REQUESTS_PER_MINUTE:'100000',ACCOUNT_REQUESTS_PER_MINUTE:'100000'},pid:1234},console:{log(){}},fetch,URL,AbortSignal,Map,Set,Date,Number,String,Array,Object,Promise,Error,Buffer,setTimeout,SharedArrayBuffer,Atomics,module:{exports:{}},};
 vm.runInNewContext(src,ctx,{filename:'server.js'});
 async function call(route,query={},opts={}){return new Promise(resolve=>{const [method,url]=route.split(' ');const headers={host:'localhost:3000',...opts.headers};const req={method,path:url,url:url,originalUrl:opts.originalUrl||url,ip:opts.ip||'127.0.0.1',headers,query,body:opts.body||{},socket:{remoteAddress:'127.0.0.1'}};
 const res={statusCode:200,headers:{},status(n){this.statusCode=n;return this},setHeader(k,v){this.headers[k.toLowerCase()]=v;return this},json(body){resolve({status:this.statusCode,body,headers:this.headers})},sendStatus(n){resolve({status:n,body:null,headers:this.headers})}};
 const handlers=[];for(const m of mw){const [prefix,...funcs]=m;if(typeof prefix==='string'){if(url.startsWith(prefix))handlers.push(...funcs.filter(x=>typeof x==='function'))}else if(typeof prefix==='function')handlers.push(prefix)}handlers.push(...(routes[route]||[]));
 let i=0;function next(){if(i>=handlers.length){resolve({status:404});return}const fn=handlers[i++];try{Promise.resolve(fn(req,res,next)).catch(e=>resolve({status:500,error:String(e)}))}catch(e){resolve({status:500,error:String(e)})}}next();})}
 return {call,get upstream(){return upstream},mw,writes};
}

(async()=>{
 const checks=[];const check=(name,pass,detail='')=>checks.push({name,pass,detail});
 const a=setup();
 const reg=await a.call('POST /api/auth/register',{}, {body:{firstName:'Test',lastName:'User',email:'portable@example.com',username:'portable',password:'SecureLongPassphrase#2026'}});
 const cookie=reg.headers['set-cookie']?.split(';')[0];
 check('account creation and password policy',reg.status===201);
 check('authenticated recommendation', (await a.call('GET /api/recommendations',{services:'netflix',genres:'Drama'},{headers:{cookie}})).status===200);
 check('health includes budget config', (await a.call('GET /api/health')).body.providerLimit===100000);
 const ip='198.51.100.33';let limited=0;for(let i=0;i<125;i++){const r=await a.call('GET /api/health',{}, {ip});if(r.status===429)limited++}
 check('per IP throttling',limited===5,`limited=${limited}`);
 const b=setup();let success=0;for(let i=0;i<100;i++){const r=await b.call('GET /api/health',{}, {ip:'198.51.100.'+(i+1)});if(r.status===200)success++}
 check('independent IPs',success===100);
 const c=setup();const results=await Promise.all(Array.from({length:30},()=>c.call('GET /api/services')));
 check('provider call deduplication',results.every(x=>x.status===200)&&c.upstream===1,`upstream=${c.upstream}`);
 const summary={total:checks.length,passed:checks.filter(x=>x.pass).length,failed:checks.filter(x=>!x.pass).length};
 fs.writeFileSync(path.join(__dirname,'v89_results.json'),JSON.stringify({method:'Offline route harness; mocked Watchmode; no real network sockets',summary,checks},null,2));
 console.log(JSON.stringify(summary));for(const x of checks.filter(x=>!x.pass))console.log('FAIL',x);
 process.exitCode=summary.failed?1:0;
})().catch(e=>{console.error(e);process.exitCode=1});
